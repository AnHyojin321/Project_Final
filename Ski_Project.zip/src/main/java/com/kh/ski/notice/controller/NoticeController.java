package com.kh.ski.notice.controller;

public class NoticeController {

}
