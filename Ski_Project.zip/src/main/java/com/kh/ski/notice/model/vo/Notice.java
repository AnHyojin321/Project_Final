package com.kh.ski.notice.model.vo;

public class Notice {

}
