package com.kh.ski.notice.model.service;

public class NoticeServiceImpl {

}
