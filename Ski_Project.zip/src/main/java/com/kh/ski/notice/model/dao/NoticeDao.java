package com.kh.ski.notice.model.dao;

public class NoticeDao {

}
