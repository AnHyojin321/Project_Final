package com.kh.ski.mypage.model.dao;

public class MyPageDao {

}
