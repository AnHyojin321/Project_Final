package com.kh.ski.mypage.model.service;

public class MyPageServiceImpl {

}
