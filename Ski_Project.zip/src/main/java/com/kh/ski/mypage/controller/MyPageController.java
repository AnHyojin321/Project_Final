package com.kh.ski.mypage.controller;

public class MyPageController {

}
