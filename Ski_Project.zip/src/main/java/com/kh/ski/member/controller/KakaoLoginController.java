package com.kh.ski.member.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kh.ski.member.model.service.KakaoService;
import com.kh.ski.member.model.vo.KakaoMemberInfo;

@RestController
public class KakaoLoginController {

    private final KakaoService kakaoService;

    public KakaoLoginController(KakaoService kakaoService) {
        this.kakaoService = kakaoService;
    }

    @GetMapping("/callback")
    public ResponseEntity<?> callback(@RequestParam("code") String code) {
        // Kakao API로부터 access token 발급
        String accessToken = kakaoService.getAccessTokenFromKakao(code);

        // Access token으로 사용자 정보 조회
        KakaoMemberInfo userInfo = kakaoService.getUserInfo(accessToken);

        // 사용자 정보 반환 (로그인/회원가입 로직 추가 가능)
        return ResponseEntity.ok(userInfo);
    }
}