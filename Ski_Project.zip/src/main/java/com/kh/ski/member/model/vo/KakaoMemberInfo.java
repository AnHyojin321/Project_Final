package com.kh.ski.member.model.vo;

import java.sql.Date;
import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

public class KakaoMemberInfo {

    // 회원 번호
    @JsonProperty("id")
    private Long id;

    // 자동 연결 설정을 비활성화한 경우만 존재.
    @JsonProperty("has_signed_up")
    private Boolean hasSignedUp;

    // 서비스에 연결 완료된 시각. UTC
    @JsonProperty("connected_at")
    private Date connectedAt;

    // 카카오싱크 간편가입을 통해 로그인한 시각. UTC
    @JsonProperty("synched_at")
    private Date synchedAt;

    // 사용자 프로퍼티
    @JsonProperty("properties")
    private HashMap<String, String> properties;

    // 카카오 계정 정보
    @JsonProperty("kakao_account")
    private KakaoAccount kakaoAccount;

    // uuid 등 추가 정보
    @JsonProperty("for_partner")
    private Partner partner;

    public KakaoMemberInfo() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getHasSignedUp() {
        return hasSignedUp;
    }

    public void setHasSignedUp(Boolean hasSignedUp) {
        this.hasSignedUp = hasSignedUp;
    }

    public Date getConnectedAt() {
        return connectedAt;
    }

    public void setConnectedAt(Date connectedAt) {
        this.connectedAt = connectedAt;
    }

    public Date getSynchedAt() {
        return synchedAt;
    }

    public void setSynchedAt(Date synchedAt) {
        this.synchedAt = synchedAt;
    }

    public HashMap<String, String> getProperties() {
        return properties;
    }

    public void setProperties(HashMap<String, String> properties) {
        this.properties = properties;
    }

    public KakaoAccount getKakaoAccount() {
        return kakaoAccount;
    }

    public void setKakaoAccount(KakaoAccount kakaoAccount) {
        this.kakaoAccount = kakaoAccount;
    }

    public Partner getPartner() {
        return partner;
    }

    public void setPartner(Partner partner) {
        this.partner = partner;
    }

    @Override
    public String toString() {
        return "KakaoMemberInfo{" +
                "id=" + id +
                ", hasSignedUp=" + hasSignedUp +
                ", connectedAt=" + connectedAt +
                ", synchedAt=" + synchedAt +
                ", properties=" + properties +
                ", kakaoAccount=" + kakaoAccount +
                ", partner=" + partner +
                '}';
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class KakaoAccount {

        @JsonProperty("profile_needs_agreement")
        private Boolean isProfileAgree;

        @JsonProperty("profile_nickname_needs_agreement")
        private Boolean isNickNameAgree;

        @JsonProperty("profile_image_needs_agreement")
        private Boolean isProfileImageAgree;

        @JsonProperty("profile")
        private Profile profile;

        @JsonProperty("name_needs_agreement")
        private Boolean isNameAgree;

        @JsonProperty("name")
        private String name;

        @JsonProperty("email_needs_agreement")
        private Boolean isEmailAgree;

        @JsonProperty("is_email_valid")
        private Boolean isEmailValid;

        @JsonProperty("is_email_verified")
        private Boolean isEmailVerified;

        @JsonProperty("email")
        private String email;

        @JsonProperty("age_range_needs_agreement")
        private Boolean isAgeAgree;

        @JsonProperty("age_range")
        private String ageRange;

        @JsonProperty("birthyear_needs_agreement")
        private Boolean isBirthYearAgree;

        @JsonProperty("birthyear")
        private String birthYear;

        @JsonProperty("birthday_needs_agreement")
        private Boolean isBirthDayAgree;

        @JsonProperty("birthday")
        private String birthDay;

        @JsonProperty("birthday_type")
        private String birthDayType;

        @JsonProperty("gender_needs_agreement")
        private Boolean isGenderAgree;

        @JsonProperty("gender")
        private String gender;

        @JsonProperty("phone_number_needs_agreement")
        private Boolean isPhoneNumberAgree;

        @JsonProperty("phone_number")
        private String phoneNumber;

        @JsonProperty("ci_needs_agreement")
        private Boolean isCIAgree;

        @JsonProperty("ci")
        private String ci;

        @JsonProperty("ci_authenticated_at")
        private Date ciCreatedAt;

        public KakaoAccount() {}

        public Boolean getIsProfileAgree() {
            return isProfileAgree;
        }

        public void setIsProfileAgree(Boolean isProfileAgree) {
            this.isProfileAgree = isProfileAgree;
        }

        public Boolean getIsNickNameAgree() {
            return isNickNameAgree;
        }

        public void setIsNickNameAgree(Boolean isNickNameAgree) {
            this.isNickNameAgree = isNickNameAgree;
        }

        public Boolean getIsProfileImageAgree() {
            return isProfileImageAgree;
        }

        public void setIsProfileImageAgree(Boolean isProfileImageAgree) {
            this.isProfileImageAgree = isProfileImageAgree;
        }

        public Profile getProfile() {
            return profile;
        }

        public void setProfile(Profile profile) {
            this.profile = profile;
        }

        public Boolean getIsNameAgree() {
            return isNameAgree;
        }

        public void setIsNameAgree(Boolean isNameAgree) {
            this.isNameAgree = isNameAgree;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Boolean getIsEmailAgree() {
            return isEmailAgree;
        }

        public void setIsEmailAgree(Boolean isEmailAgree) {
            this.isEmailAgree = isEmailAgree;
        }

        public Boolean getIsEmailValid() {
            return isEmailValid;
        }

        public void setIsEmailValid(Boolean isEmailValid) {
            this.isEmailValid = isEmailValid;
        }

        public Boolean getIsEmailVerified() {
            return isEmailVerified;
        }

        public void setIsEmailVerified(Boolean isEmailVerified) {
            this.isEmailVerified = isEmailVerified;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public Boolean getIsAgeAgree() {
            return isAgeAgree;
        }

        public void setIsAgeAgree(Boolean isAgeAgree) {
            this.isAgeAgree = isAgeAgree;
        }

        public String getAgeRange() {
            return ageRange;
        }

        public void setAgeRange(String ageRange) {
            this.ageRange = ageRange;
        }

        public Boolean getIsBirthYearAgree() {
            return isBirthYearAgree;
        }

        public void setIsBirthYearAgree(Boolean isBirthYearAgree) {
            this.isBirthYearAgree = isBirthYearAgree;
        }

        public String getBirthYear() {
            return birthYear;
        }

        public void setBirthYear(String birthYear) {
            this.birthYear = birthYear;
        }

        public Boolean getIsBirthDayAgree() {
            return isBirthDayAgree;
        }

        public void setIsBirthDayAgree(Boolean isBirthDayAgree) {
            this.isBirthDayAgree = isBirthDayAgree;
        }

        public String getBirthDay() {
            return birthDay;
        }

        public void setBirthDay(String birthDay) {
            this.birthDay = birthDay;
        }

        public String getBirthDayType() {
            return birthDayType;
        }

        public void setBirthDayType(String birthDayType) {
            this.birthDayType = birthDayType;
        }

        public Boolean getIsGenderAgree() {
            return isGenderAgree;
        }

        public void setIsGenderAgree(Boolean isGenderAgree) {
            this.isGenderAgree = isGenderAgree;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public Boolean getIsPhoneNumberAgree() {
            return isPhoneNumberAgree;
        }

        public void setIsPhoneNumberAgree(Boolean isPhoneNumberAgree) {
            this.isPhoneNumberAgree = isPhoneNumberAgree;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public Boolean getIsCIAgree() {
            return isCIAgree;
        }

        public void setIsCIAgree(Boolean isCIAgree) {
            this.isCIAgree = isCIAgree;
        }

        public String getCi() {
            return ci;
        }

        public void setCi(String ci) {
            this.ci = ci;
        }

        public Date getCiCreatedAt() {
            return ciCreatedAt;
        }

        public void setCiCreatedAt(Date ciCreatedAt) {
            this.ciCreatedAt = ciCreatedAt;
        }

        @Override
        public String toString() {
            return "KakaoAccount{" +
                    "isProfileAgree=" + isProfileAgree +
                    ", isNickNameAgree=" + isNickNameAgree +
                    ", isProfileImageAgree=" + isProfileImageAgree +
                    ", profile=" + profile +
                    ", isNameAgree=" + isNameAgree +
                    ", name='" + name + '\'' +
                    ", isEmailAgree=" + isEmailAgree +
                    ", isEmailValid=" + isEmailValid +
                    ", isEmailVerified=" + isEmailVerified +
                    ", email='" + email + '\'' +
                    ", isAgeAgree=" + isAgeAgree +
                    ", ageRange='" + ageRange + '\'' +
                    ", isBirthYearAgree=" + isBirthYearAgree +
                    ", birthYear='" + birthYear + '\'' +
                    ", isBirthDayAgree=" + isBirthDayAgree +
                    ", birthDay='" + birthDay + '\'' +
                    ", birthDayType='" + birthDayType + '\'' +
                    ", isGenderAgree=" + isGenderAgree +
                    ", gender='" + gender + '\'' +
                    ", isPhoneNumberAgree=" + isPhoneNumberAgree +
                    ", phoneNumber='" + phoneNumber + '\'' +
                    ", isCIAgree=" + isCIAgree +
                    ", ci='" + ci + '\'' +
                    ", ciCreatedAt=" + ciCreatedAt +
                    '}';
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Profile {

            @JsonProperty("nickname")
            private String nickName;

            @JsonProperty("thumbnail_image_url")
            private String thumbnailImageUrl;

            @JsonProperty("profile_image_url")
            private String profileImageUrl;

            @JsonProperty("is_default_image")
            private String isDefaultImage;

            @JsonProperty("is_default_nickname")
            private Boolean isDefaultNickName;

            public Profile() {}

            public String getNickName() {
                return nickName;
            }

            public void setNickName(String nickName) {
                this.nickName = nickName;
            }

            public String getThumbnailImageUrl() {
                return thumbnailImageUrl;
            }

            public void setThumbnailImageUrl(String thumbnailImageUrl) {
                this.thumbnailImageUrl = thumbnailImageUrl;
            }

            public String getProfileImageUrl() {
                return profileImageUrl;
            }

            public void setProfileImageUrl(String profileImageUrl) {
                this.profileImageUrl = profileImageUrl;
            }

            public String getIsDefaultImage() {
                return isDefaultImage;
            }

            public void setIsDefaultImage(String isDefaultImage) {
                this.isDefaultImage = isDefaultImage;
            }

            public Boolean getIsDefaultNickName() {
                return isDefaultNickName;
            }

            public void setIsDefaultNickName(Boolean isDefaultNickName) {
                this.isDefaultNickName = isDefaultNickName;
            }

            @Override
            public String toString() {
                return "Profile{" +
                        "nickName='" + nickName + '\'' +
                        ", thumbnailImageUrl='" + thumbnailImageUrl + '\'' +
                        ", profileImageUrl='" + profileImageUrl + '\'' +
                        ", isDefaultImage='" + isDefaultImage + '\'' +
                        ", isDefaultNickName=" + isDefaultNickName +
                        '}';
            }
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Partner {

        @JsonProperty("uuid")
        private String uuid;

        public Partner() {}

        public String getUuid() {
            return uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        @Override
        public String toString() {
            return "Partner{" +
                    "uuid='" + uuid + '\'' +
                    '}';
        }
    }
}
