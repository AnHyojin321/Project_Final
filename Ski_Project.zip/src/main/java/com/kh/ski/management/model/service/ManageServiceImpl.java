package com.kh.ski.management.model.service;

public class ManageServiceImpl {

}
