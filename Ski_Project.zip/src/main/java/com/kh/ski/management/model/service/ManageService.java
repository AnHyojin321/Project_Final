package com.kh.ski.management.model.service;

public class ManageService {

}
