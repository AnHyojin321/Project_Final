package com.kh.ski.management.model.dao;

public class ManageDao {

}
