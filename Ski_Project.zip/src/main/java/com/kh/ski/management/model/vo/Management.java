package com.kh.ski.management.model.vo;

public class Management {

}
