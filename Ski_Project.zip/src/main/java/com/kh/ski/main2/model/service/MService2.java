package com.kh.ski.main2.model.service;

import org.springframework.stereotype.Service;

@Service
public class MService2 {
    // 서비스 로직
    public void processBeforeRedirect() {
        // 리다이렉트 전에 처리할 로직
    }
}
