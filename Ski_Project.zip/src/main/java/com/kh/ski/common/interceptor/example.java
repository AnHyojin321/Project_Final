package com.kh.ski.common.interceptor;

public class example {
	
	// 깃허브에 폴더 올리기 위해 임시로 생성한 파일임

}
