package com.kh.ski.common.model.service;

import org.springframework.stereotype.Service;

@Service
public class MenuService {

    public void processBeforeRedirect() {
        // 메뉴 바를 표시하기 전에 필요한 로직을 작성
        // 예: 데이터베이스 조회, 로그 기록 등
    }
}